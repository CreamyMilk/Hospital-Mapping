const express = require('express')
const Datastore = require('nedb')
const app = express()
const cors = require('cors')

app.use(cors())
app.use(express.json())
app.listen(8081)
app.use(express.static('public'));
let key;
const db = new Datastore('database.db');
db.loadDatabase();
app.get('/',(req,res)=>{
    res.send({
        name:'Jotham'  
    })
})

app.post('/api',(req,res)=>{
    const data = req.body
    console.log(data)
    res.json({'boy':'fdfd'})
    db.insert(data,(err,newDat)=>{
        key = newDat._id
        
    })
    console.log(key)
})

app.get('/api',(req,res)=>{
    db.find({}, function (err, docs) {
        res.send(docs)
      });
})
