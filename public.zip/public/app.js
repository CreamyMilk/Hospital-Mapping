console.log('bopuy we connecterd')
//Med Icon
const hospital = {
    Central:[-1.285421, 36.811581],
    Kenyatta:[-1.296705, 36.804414],
    Coptic:[-1.298035, 36.797633],
    NairobiW:[-1.306573, 36.825871]
}
const mymap = L.map('mapid').setView([-1.2841, 36.9155], 16);
L.tileLayer('https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token={accessToken}', {
    attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, <a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
    maxZoom: 18,
    id: 'mapbox/streets-v11',
    tileSize: 512,
    zoomOffset: -1,
    accessToken: 'pk.eyJ1IjoiaG9tZXIyNTQiLCJhIjoiY2s3cTkyczY5MDExeDNmbnZ2bjBxcHJxaCJ9.VlYz-NWHKnwW98GUMCSkzA'
}).addTo(mymap);


const x= L.marker(hospital.Kenyatta).addTo(mymap);
x.bindPopup("<b><img src='https://www.google.com/favicon.ico'></b><ul><li>op</li></ul><br>I am a popup.").openPopup();
const marker = L.marker(hospital.Central).addTo(mymap);
const hosi = L.marker([-1.2841, 36.9155]).addTo(mymap);
for (const key in hospital){
    L.marker(hospital[key]).addTo(mymap)
}

const circle = L.circle([-1.2841, 36.9155], {
    color: 'red',
    fillColor: '#f03',
    fillOpacity: 0.1,
    radius: 500
}).addTo(mymap);
//
animateCirle()

function onMapClick(e) {
    alert("You clicked the map at " + e.latlng);
    
}

x.on('click', onMapClick);

function getCords(){
    if('geolocation' in navigator){
        console.log('Geo lOcal available')
     
    navigator.geolocation.getCurrentPosition((pos)=>{
        const {latitude ,longitude} = pos.coords
        console.log(latitude)
        console.log(longitude)
    })
} else{
    console.log('HAki pole browser yako ina ringa')
  }
}

function animateCirle(){
    var circle = L.circleMarker([-1.2841, 36.9155], {radius: 5}).addTo(mymap);


    var newRadius = 250;
    var interval = setInterval(function() {
    var currentRadius = circle.getRadius();
    console.debug("currentRadius", currentRadius);
    if (currentRadius < newRadius) {
        circle.setRadius(++currentRadius);
        console.debug("new Radius", circle.getRadius());
    } else {
        clearInterval(interval);
    }
    }, 1);
}

